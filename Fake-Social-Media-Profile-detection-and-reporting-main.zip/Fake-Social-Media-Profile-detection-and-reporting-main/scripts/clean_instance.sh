#!/usr/bin/env bash

sudo rm -rf /home/ubuntu/Fake_Social_Media_Profile_Detection/*